﻿using System;

namespace AttachcMore.NextGen.Core.IAWS
{
    public class Class1
    {
    }
}
