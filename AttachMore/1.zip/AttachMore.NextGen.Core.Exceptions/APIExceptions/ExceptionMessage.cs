﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttachMore.NextGen.Core.Exceptions.APIExceptions
{
    public class ExceptionMessage 
    {
        //public string Message(string ErrorMessage)
        //{
        //    var result = string.Format("{0}{1}{2}",)
        //}
    }
}
