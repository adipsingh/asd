﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttachMore.NextGen.Core.IServices.Log
{
    /// <summary>
    /// Log Service
    /// </summary>
    public interface ILogService
    {
        /// <summary>
        /// Logs the activity.
        /// </summary>
        /// <param name="ActivityLogType">Type of the activity log.</param>
        /// <param name="logDescription">The log description.</param>
        /// <param name="LogEntityId">The log entity identifier.</param>
        /// <param name="LogEntityName">Name of the log entity.</param>
        /// <param name="UserId">The user identifier.</param>
        void LogActivity(int ActivityLogType, string logDescription, int LogEntityId, string LogEntityName, int UserId);
    }
}
